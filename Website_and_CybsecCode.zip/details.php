<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archer Details</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <?php
        if (isset($_GET['archerID']) && !empty($_GET['archerID'])) {
            $archerID = $_GET['archerID'];

            require_once "settings.php";
            $conn = mysqli_connect($host, $user, $pwd, $sql_db);

            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            //Sanitise inputs function
            function sanitise_input($data) {
                $data = trim($data);
                $data = stripcslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            // Fetch archer details
            $sql_archer = "SELECT a.archerID, a.firstName, a.lastName, a.dateOfBirth, g.gender
               FROM archer a
               JOIN gender_lookup g ON a.genderID = g.genderID
               WHERE a.archerID = ?";

            $stmt_archer = mysqli_prepare($conn, $sql_archer);
            mysqli_stmt_bind_param($stmt_archer, 'i', $archerID);
            mysqli_stmt_execute($stmt_archer);
            $result_archer = mysqli_stmt_get_result($stmt_archer);

            if (mysqli_num_rows($result_archer) > 0) {
                $row_archer = mysqli_fetch_assoc($result_archer);
                echo "<h1> Archer  Details: " . $row_archer['firstName'] . " " . $row_archer['lastName'] . "</h1>";
                echo "<p>Date of Birth: " . $row_archer['dateOfBirth'] . "</p>";
                echo "<p>Gender: " . $row_archer['gender'] . "</p>";
            } else {
                echo "<p>Archer not found.</p>";
            }

            // Add form for date range input
            echo "<hr>";
            echo "<h3>Rounds:</h3>";
            echo "<form action='' method='POST'>
                    <label for='start_date'>Start Date:</label>
                    <input type='date' id='start_date' name='start_date'>

                    <label for='end_date'>End Date:</label>
                    <input type='date' id='end_date' name='end_date'>

                    <input type='submit' name='submit' value='Filter'>
                  </form>";

            $start_date = (isset($_POST['start_date']) && !empty($_POST['start_date'])) ? $_POST['start_date'] : '1970-01-01';  
            $end_date = (isset($_POST['end_date']) && !empty($_POST['end_date'])) ? $_POST['end_date'] : date("Y-m-d");  
            
            // Fetch round details
            $sql_rounds = "SELECT rl.roundName, r.date, r.roundNo,  SUM(e.pointsNo) score, cl.classDescription, dl.divisionDescription
               FROM round r
               JOIN category_lookup c ON r.categoryID = c.categoryID
               JOIN class_lookup cl ON c.classID = cl.classID
               JOIN division_lookup dl ON c.divisionID = dl.divisionID
               JOIN round_lookup rl ON r.roundID = rl.roundID
               JOIN `range` ra ON r.roundNo = ra.roundNo
               JOIN `end` e ON ra.rangeNo = e.rangeNo
               WHERE r.officialScore = '1' AND r.archerID = ? AND r.date BETWEEN ? AND ?
               GROUP BY r.roundNo
               ORDER BY score DESC";

            $stmt_rounds = mysqli_prepare($conn, $sql_rounds);

            if ($stmt_rounds) {
                mysqli_stmt_bind_param($stmt_rounds, 'iss', $archerID, $start_date, $end_date);
                mysqli_stmt_execute($stmt_rounds);
                $result_rounds = mysqli_stmt_get_result($stmt_rounds);

                if (mysqli_num_rows($result_rounds) > 0) {

                    echo "<table class='table table-striped'>";
                    echo "<thead>";
                    echo "<tr><th>Round Name</th><th>Date</th><th>Round No</th><th>Score</th><th>Class</th><th>Division</th></tr>";
                    echo "</thead>";
                    echo "<tbody>";

                    while ($row_rounds = mysqli_fetch_assoc($result_rounds)) {
                        echo "<tr>";
                        echo "<td>" . $row_rounds['roundName'] . "</td>";
                        echo "<td>" . $row_rounds['date'] . "</td>";
                        echo "<td>" . $row_rounds['roundNo'] . "</td>";
                        echo "<td>" . $row_rounds['score'] . "</td>";
                        echo "<td>" . $row_rounds['classDescription'] . "</td>";
                        echo "<td>" . $row_rounds['divisionDescription'] . "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p>No rounds found for this archer.</p>";
                }
            } else {
                echo "Error: " . mysqli_error($conn);
            }



            // Query to fetch competition, championship, class, division, and whether the archer has won or not
            $sql_winnings = "SELECT c.compName, cc.clubChampionshipName, cl.classDescription, d.divisionDescription, w.archerID AS winner
            FROM round r
            JOIN competition c ON r.roundNo = c.roundNo
            JOIN club_championship cc ON c.compID = cc.compID
            JOIN category_lookup cat ON r.categoryID = cat.categoryID
            JOIN class_lookup cl ON cat.classID = cl.classID
            JOIN division_lookup d ON cat.divisionID = d.divisionID
            LEFT JOIN winner w ON r.roundNo = w.roundNo AND r.archerID = w.archerID
            WHERE r.officialScore = '1' AND r.archerID = ? ";

            $stmt2 = mysqli_prepare($conn, $sql_winnings); //Prepare the query and saves to stmt2
            mysqli_stmt_bind_param($stmt2, 'i', $archerID); //Use the archerID in the ? placeholder of $sql_winnings
            mysqli_stmt_execute($stmt2); //Execute the query using archerID
            $result2 = mysqli_stmt_get_result($stmt2); //Saves results to $result2

            if (mysqli_num_rows($result2) > 0) {
                echo "<h3>Competitions and Championships</h3>";
                echo "<table class='table table-striped'>";
                echo "<thead>";
                echo "<tr><th>Competition</th><th>Championship</th><th>Class</th><th>Division</th><th>Winner</th></tr>";
                echo "</thead>";
                echo "<tbody>";

                while ($row2 = mysqli_fetch_assoc($result2)) {
                    echo "<tr>";
                    echo "<td>" . $row2['compName'] . "</td>";
                    echo "<td>" . $row2['clubChampionshipName'] . "</td>";
                    echo "<td>" . $row2['classDescription'] . "</td>";
                    echo "<td>" . $row2['divisionDescription'] . "</td>";
                    echo "<td>" . (!is_null($row2['winner']) ? 'Yes' : 'No') . "</td>";
                    echo "</tr>";
                }
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<hr>";
                echo "<h3>Competitions and Championships:</h3>";
                echo "<p>No competitions or championships found for this archer.</p>";
            }

            mysqli_close($conn);
        } else {
            echo "<p>No Archer ID provided.</p>";
        }

        ?>

        <a href="index.php" class="btn btn-primary mt-3">Back to Archers</a>
    </div>
</body>

</html>