<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Archery Scoring System</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>

<body>
    <div class="container py-5">
        <?php
        //Connect to database
        require_once("settings.php");
        $conn = mysqli_connect($host, $user, $pwd, $sql_db);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get Rounds
        $rounds = [];
        $sql = "SELECT roundID, roundName FROM round_lookup";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $rounds[$row['roundID']] = $row['roundName'];
            }
        }

        // Get Divisions
        $divisions = [];
        $sql = "SELECT divisionID, divisionDescription FROM division_lookup";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $divisions[$row['divisionID']] = $row['divisionDescription'];
            }
        }

        // Get Archers
        $archers = [];
        $sql = "SELECT archerID, firstName, lastName FROM archer";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $archers[$row['archerID']] = $row['firstName'] . ' ' . $row['lastName'];
            }
        }

        // Get Distances
        $distances = [];
        $sql = "SELECT distanceID, distance FROM distance_lookup";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $distances[$row['distanceID']] = $row['distance'];
            }
        }

        // Get Target Faces
        $targetFaces = [];
        $sql = "SELECT targetFaceID, targetFace FROM targetface_lookup";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $targetFaces[$row['targetFaceID']] = $row['targetFace'];
            }
        }


        ?>
        <div class="row">
            <div class="col-md-6">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="mb-5">
                    <h2>Enter your details</h2>
                    <div class="form-group">
                        <label for="round">Round:</label>
                        <select name="round" id="round" class="form-control">
                            <?php foreach ($rounds as $id => $name) : ?>
                                <option value="<?php echo $id; ?>"><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="division">Division:</label>
                        <select name="division" id="division" class="form-control">
                            <?php foreach ($divisions as $id => $description) : ?>
                                <option value="<?php echo $id; ?>"><?php echo $description; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="archer">Archer:</label>
                        <select name="archer" id="archer" class="form-control">
                            <?php foreach ($archers as $id => $name) : ?>
                                <option value="<?php echo $id; ?>"><?php echo $name; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="ends">Ends:</label>
                        <select name="ends" id="ends" class="form-control" required>
                            <option value=1>1</option>
                            <option value=2>2</option>
                            <option value=3>3</option>
                            <option value=4>4</option>
                            <option value=5>5</option>
                            <option value=6>6</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="distance">Distance (m):</label>
                        <select name="distance" id="distance" class="form-control">
                            <?php foreach ($distances as $id => $distance) : ?>
                                <option value="<?php echo $id; ?>"><?php echo $distance; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="targetFace">Target Face (cm):</label>
                        <select name="targetFace" id="targetFace" class="form-control">
                            <?php foreach ($targetFaces as $id => $targetFace) : ?>
                                <option value="<?php echo $id; ?>"><?php echo $targetFace; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>



                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>

                <?php
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $round = $_POST["round"];
                    $division = $_POST["division"];
                    $archer = $_POST["archer"];
                    $ends = $_POST["ends"];
                    $distanceID = $_POST["distance"];
                    $targetFaceID = $_POST["targetFace"];

                    // Fetch roundName
                    $roundName = "";
                    $roundQuery = "SELECT roundName FROM round_lookup WHERE roundID = $round";
                    $result = $conn->query($roundQuery);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $roundName = $row["roundName"];
                    }

                    // Fetch divisionDescription
                    $divisionDescription = "";
                    $divisionQuery = "SELECT divisionDescription FROM division_lookup WHERE divisionID = $division";
                    $result = $conn->query($divisionQuery);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $divisionDescription = $row["divisionDescription"];
                    }

                    // Fetch archer's firstName and lastName
                    $firstName = "";
                    $lastName = "";
                    $archerQuery = "SELECT firstName, lastName FROM archer WHERE archerID = $archer";
                    $result = $conn->query($archerQuery);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $firstName = $row["firstName"];
                        $lastName = $row["lastName"];
                    }

                    // Fetch distance
                    $distance = 0;
                    $distanceQuery = "SELECT distance FROM distance_lookup WHERE distanceID = $distanceID";
                    $result = $conn->query($distanceQuery);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $distance = $row["distance"];
                    }

                    // Fetch targetFace
                    $targetFace = "";
                    $targetFaceQuery = "SELECT targetFace FROM targetface_lookup WHERE targetFaceID = $targetFaceID";
                    $result = $conn->query($targetFaceQuery);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        $targetFace = $row["targetFace"];
                    }

                ?>

                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <th>Round</th>
                                <td><?php echo $roundName; ?></td>
                            </tr>
                            <tr>
                                <th>Division</th>
                                <td><?php echo $divisionDescription; ?></td>
                            </tr>
                            <tr>
                                <th>Archer's Name</th>
                                <td><?php echo $firstName . " " . $lastName; ?></td>
                            </tr>
                            <tr>
                                <th>Ends</th>
                                <td><?php echo $ends; ?></td>
                            </tr>
                            <tr>
                                <th>Distance (m)</th>
                                <td><?php echo $distance; ?></td>
                            </tr>
                            <tr>
                                <th>Target Face (cm)</th>
                                <td><?php echo $targetFace; ?></td>
                            </tr>
                        </tbody>
                    </table>
                <?php
                }

                mysqli_close($conn);
                ?>
            </div>

            <div class="col-md-6">
                <form id="score-form" class="mb-5">
                    <h2>Enter your score</h2>
                    <div class="form-group">
                        <label for="score1">Score 1:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score1" required>
                    </div>

                    <div class="form-group">
                        <label for="score2">Score 2:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score2" required>
                    </div>

                    <div class="form-group">
                        <label for="score3">Score 3:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score3" required>
                    </div>

                    <div class="form-group">
                        <label for="score4">Score 4:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score4" required>
                    </div>

                    <div class="form-group">
                        <label for="score5">Score 5:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score5" required>
                    </div>

                    <div class="form-group">
                        <label for="score6">Score 6:</label>
                        <input type="text" class="form-control score-input" name="scores[]" id="score6" required>
                    </div>


                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
                
                    
                

                <div class="container">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>End</th>
                                <th>Total Score</th>
                            </tr>
                        </thead>
                        <tbody id="score-table-body">
                            <p id="totalOfTotals">Total of All Totals: 0</p>
                        </tbody>
                    </table>
                </div>

            </div>
            <div class="center">
            <a href="index.php" class="btn btn-primary">Back to Archers</a>
            </div>
        </div>
    </div>

    <script>
        var totalArray = []; // Array to store the total scores

        document.getElementById('score-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the form from being submitted normally

            var scores = document.getElementsByClassName('score-input');
            var total = 0;

            for (var i = 0; i < scores.length; i++) {
                var scoreValue = scores[i].value.toUpperCase() === 'X' ? 10 : Number(scores[i].value);
                total += scoreValue; // Add the score to the total
            }

            totalArray.push(total); // Add the total to the totalArray

            // Reset the form
            document.getElementById('score-form').reset();

            // Update the score table
            updateScoreTable();
            calculateTotalOfTotals();
        });

        function updateScoreTable() {
            var tableBody = document.getElementById('score-table-body');
            tableBody.innerHTML = ''; // Clear the table body

            for (var i = 0; i < totalArray.length; i++) {
                var row = document.createElement('tr');
                var serialCell = document.createElement('td');
                serialCell.textContent = i + 1;
                var scoreCell = document.createElement('td');
                scoreCell.textContent = totalArray[i];

                row.appendChild(serialCell);
                row.appendChild(scoreCell);
                tableBody.appendChild(row);
            }
        }

        function calculateTotalOfTotals() {
            var totalOfTotals = 0;
            for (var i = 0; i < totalArray.length; i++) {
                totalOfTotals += totalArray[i];
            }
            document.getElementById('totalOfTotals').textContent = 'Total of All Totals: ' + totalOfTotals;
        }
    </script>


</body>

</html>