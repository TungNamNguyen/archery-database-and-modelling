<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Archery Database</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
</head>

<body>

	<div class="container">
		<h1 class="mt-3">Archery Database</h1>
		<h2>Search</h2>
		<form action="index.php" method="get">
			<div class="form-group">
				<label for="firstName">First Name:</label>
				<input type="text" name="firstName" id="firstName" class="form-control">
			</div>
			<div class="form-group">
				<label for="lastName">Last Name:</label>
				<input type="text" name="lastName" id="lastName" class="form-control">
			</div>
			<div class="form-group">
				<label for="archerID">Archer ID:</label>
				<input type="number" name="archerID" id="archerID" class="form-control">
			</div>
			<div class="form-group">
				<label>Gender:</label>
				<div class="form-check">
					<input type="radio" name="genderID" id="male" value="1" class="form-check-input">
					<label for="male" class="form-check-label">Male</label>
				</div>
				<div class="form-check">
					<input type="radio" name="genderID" id="female" value="2" class="form-check-input">
					<label for="female" class="form-check-label">Female</label>
				</div>
			</div>
			<input type="submit" value="Search" class="btn btn-primary">
		</form>

		<hr>

		<?php
		//Connect to database
		require_once("settings.php");
		$conn = mysqli_connect($host, $user, $pwd, $sql_db);

		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}

		//Sanitise inputs function
		function sanitise_input($data)
		{
			$data = trim($data);
			$data = stripcslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}

		//Get search parameters, return empty if not set
		$firstName = $_GET['firstName'] ?? '';
		$firstName = sanitise_input($firstName);
		$lastName = $_GET['lastName'] ?? '';
		$lastName = sanitise_input($lastName);
		$archerID = $_GET['archerID'] ?? '';
		$archerID = sanitise_input($archerID);
		$genderID = $_GET['genderID'] ?? '';
		$genderID = sanitise_input($genderID);

		//Create array of search conditions
		$searchConditions = array();
		$placeholders = array();

		if (!empty($firstName)) {
			$searchConditions[] = "a.firstName LIKE ?";
			$placeholders[] = '%' . $firstName . '%';
		}

		if (!empty($lastName)) {
			$searchConditions[] = "a.lastName LIKE ?";
			$placeholders[] = '%' . $lastName . '%';
		}

		if (!empty($archerID)) {
			$searchConditions[] = "a.archerID = ?";
			$placeholders[] = $archerID;
		}

		if (!empty($genderID)) {
			$searchConditions[] = "a.genderID = ?";
			$placeholders[] = $genderID;
		}

		// Build the SQL query
		$sql = "SELECT a.archerID, a.firstName, a.lastName, a.dateOfBirth, g.gender
						FROM archer a
						JOIN gender_lookup g ON a.genderID = g.genderID";

		if (!empty($searchConditions)) {
			$sql .= " WHERE " . implode(" AND ", $searchConditions);
		}

		// Pagination 
		$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
		$limit = 10;
		$offset = ($currentPage - 1) * $limit;
		$sql .= " ORDER BY a.archerID LIMIT $limit OFFSET $offset";

		// if no search conditions do not create search or create table
		if (!empty($searchConditions)) {
			//Prepare the SQL statement
			$stmt = mysqli_prepare($conn, $sql);

			if (!$stmt) {
				die("Error in statement preparation: " . mysqli_error($conn));
			}

			echo "
					<h2>Archers Information</h2>
					<table class=\"table table-striped table-bordered\">
						<thead>
							<tr>
								<th>Archer ID</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Date of Birth</th>
								<th>Gender</th>
								<th>Details</th>
							</tr>
						</thead>
						<tbody>
					";

			//Bind parameters to the SQL statement
			if (!empty($placeholders)) {
				$paramTypes = str_repeat("s", count($placeholders));
				$bindParams = array($stmt, $paramTypes);
				foreach ($placeholders as &$param) {
					$bindParams[] = &$param;
				}
				call_user_func_array('mysqli_stmt_bind_param', $bindParams);
			}

			//Execute the SQL statement
			if (!mysqli_stmt_execute($stmt)) {
				die("Error in statement execution: " . mysqli_error($conn));
			}

			//Retrieve the result set from the SQL statement
			$result = mysqli_stmt_get_result($stmt);

			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo "<td>" . $row['archerID'] . "</td>";
					echo "<td>" . $row['firstName'] . "</td>";
					echo "<td>" . $row['lastName'] . "</td>";
					echo "<td>" . $row['dateOfBirth'] . "</td>";
					echo "<td>" . $row['gender'] . "</td>";
					echo "<td><a href='details.php?archerID=" . $row['archerID'] . "'>View Details</a></td>";
					echo "</tr>";
				}
			} else {
				echo "<tr><td colspan='6'>No results found.</td></tr>";
			}
			echo "</tbody>";
			echo "</table>";
			mysqli_stmt_close($stmt);
		}

		?>

	</div>

	<div class="container">
	<a href="enter_score.php" class="btn btn-primary">Enter Scores</a>
	</div>

	<script>
		var totalArray = []; // Array to store the total scores

		document.getElementById('score-form').addEventListener('submit', function(event) {
			event.preventDefault(); // Prevent the form from being submitted normally

			var scores = document.getElementsByClassName('score-input');
			var total = 0;

			for (var i = 0; i < scores.length; i++) {
				var scoreValue = scores[i].value.toUpperCase() === 'X' ? 10 : Number(scores[i].value);
				total += scoreValue; // Add the score to the total
			}

			totalArray.push(total); // Add the total to the totalArray

			// Reset the form
			document.getElementById('score-form').reset();

			// Update the score table
			updateScoreTable();
			calculateTotalOfTotals();
		});

		function updateScoreTable() {
			var tableBody = document.getElementById('score-table-body');
			tableBody.innerHTML = ''; // Clear the table body

			for (var i = 0; i < totalArray.length; i++) {
				var row = document.createElement('tr');
				var serialCell = document.createElement('td');
				serialCell.textContent = i + 1;
				var scoreCell = document.createElement('td');
				scoreCell.textContent = totalArray[i];

				row.appendChild(serialCell);
				row.appendChild(scoreCell);
				tableBody.appendChild(row);
			}
		}

		function calculateTotalOfTotals() {
			var totalOfTotals = 0;
			for (var i = 0; i < totalArray.length; i++) {
				totalOfTotals += totalArray[i];
			}
			document.getElementById('totalOfTotals').textContent = 'Total: ' + totalOfTotals;
		}
	</script>
</body>

</html>