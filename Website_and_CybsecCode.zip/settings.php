
<?php
#header ("location: index.php");
#exit();

#$host = "http://18.191.224.239/phpMyAdmin";
$servername = "localhost";
$user = "data_entry";
$pwd = "d*S]yEFvjbtJQp)I";
$sql_db = "COS20031";
?>