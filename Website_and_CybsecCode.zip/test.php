<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Archery Database</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css">
</head>

<body>
<h1>Page loaded correctly</h1>

<?php
    header ("location: index.php");
    exit();
    $heata = "`round_lookup`";

    function sanitise_input($data) {
        $data = trim($data);
        $data = stripcslashes($data);
        $data = htmlspecialchars($data);
        return $data;
        
    }
    
    //Connect to database
    require_once("settings.php");
    $conn = mysqli_connect($host, $user, $pwd, $sql_db);
    //debug ONLY
    $sqltest = "SELECT * FROM ";
  
    $query = sanitise_input($heata);
    $query2 = $sqltest . $query;
    //echo "<p>query2</p>":
    echo "\n\n$query2";

    $result = mysqli_query($conn, $query2);

    
    
    echo "<p> $heata </p>";
    echo "<p>No archers found</p>";
    
    if (!$result) {
        echo "<p> Something is wrong with", $query, "</p>";
    }
    else if (mysqli_num_rows($result) > 0) {
        echo "<table class='table table-striped table-bordered'>";
        echo "<tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['archerID'] . "</td>";
            echo "<td>" . $row['firstName'] . "</td>";
            echo "<td>" . $row['lastName'] . "</td>";
            echo "<td>" . $row['dateOfBirth'] . "</td>";
            echo "<td>" . $row['gender'] . "</td>";
            echo "<td><a href='details.php?archerID=" . $row['archerID'] . "'>View Details</a></td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        echo "<hr>";
    } else {
        echo "<p>No archers found</p>";
    }

    mysqli_close($conn);
    echo "<p>No archers found</p>";

    
?>


</body>